1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1d4h-sglyo8ft.js","/_next/static/chunks/14mumt5_n0xhi.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"flex flex-col flex-1 items-center justify-center bg-zinc-50 font-sans dark:bg-black","children":["$","div",null,{"children":[["$","h1",null,{"children":"SAV"}],["$","h1",null,{"children":"YA NEBİ SELAM ALEYKE"}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/0on9ev1fw2cou.js","async":true}]],["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"bRQ3dmr66qPxfMDgFBtB-"}
4:null
