module.exports=[29735,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("html",{lang:"tr",children:(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})})},"metadata",0,{title:"Namaz Rehberi Sitesi",description:"Namaz Rehberi "}])},81967,a=>{a.n(a.i(29735))}];

//# sourceMappingURL=src_app_layout_0i0xrt7.js.map